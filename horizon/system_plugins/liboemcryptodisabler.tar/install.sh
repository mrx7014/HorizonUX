function liboemcryptodisabler() {
	local system="$1"
	local vendor="$3"
    local so="liboemcrypto.so"
	
	# check if the args are enough to run this function..
	if [ "$#" -ne "2" ]; then
		warns "Arguments are not enough for this script to run, the lib won't be patched...." "LIBENCRYPTO_DISABLER"
		return 1
	fi
	
	# the main " modding " stuffs starts from here.
	warns "This patch is not necessary on SM-G975F SM-G973F & SM-G970F samsung models."
    for part in $system $vendor; do
        for libdir in $part/lib $part/lib64; do
            if [ -f $part/$libdir/$so ]; then
                size=$(ls -l /$part/$libdir/$so | awk '{print $5}')
                touch "/$part/$libdir/$so"
            fi
        done
    done
}

liboemcryptodisabler;